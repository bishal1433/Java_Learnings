import classes.SafeTask;
import classes.TaskRegistry;
import classes.TaskScheduler;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello and welcome to Java!");

        /*
            TaskRegistry registry = new TaskRegistry();
            long taskId1 = registry.register(() -> System.out.println("Executing Task 1"));
            long taskId2 = registry.register(() -> System.out.println("Executing Task 2"));

            System.out.println("Registered tasks: " + registry.getTaskCount());
            registry.getTask(taskId1).run();
            registry.getTask(taskId2).run();

            SafeTask taskRemoved = registry.removeTask(taskId1);
            System.out.println("Removed task: " + taskRemoved.getTaskName());
            System.out.println("Remaining tasks: " + registry.getTaskCount());
         */

        TaskScheduler scheduler = new TaskScheduler(3,false);

        long taskId = scheduler.register(() -> {
            try {
                Thread.sleep(10000);
            } catch (InterruptedException ignored) {}
            System.out.println(
                    "Executing in thread: " + Thread.currentThread().getName()
            );

        });
        long taskId2 = scheduler.register(() -> {
            try {
                Thread.sleep(3000);
            } catch (InterruptedException ignored) {}
            System.out.println(
                    "Executing in thread: " + Thread.currentThread().getName()
            );

        });

        scheduler.execute(taskId);
        scheduler.execute(taskId2);
        System.out.println("Main thread continues...");

        scheduler.shutdown();


    }
}