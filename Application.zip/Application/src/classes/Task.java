package classes;

@FunctionalInterface
public interface Task {
    void execute();
}
