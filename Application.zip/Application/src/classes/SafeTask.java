package classes;

public class SafeTask {
    private final Task task;
    private final String name;

    public SafeTask(Task task, String name) {
        this.task = task;
        this.name = name;
    }

    public void run() {
        try {
            task.execute();
        } catch (Exception e) {
            System.err.println("Error executing task '" + name);
            e.printStackTrace();
        }
    }

    public String getTaskName(){
        return name;
    }
}
