package classes;

public class TaskScheduler {
    private final TaskRegistry taskRegistry;
    private final TaskExecutor taskExecutor;

    public TaskScheduler(int poolSize) {
        this.taskRegistry = new TaskRegistry();
        this.taskExecutor = new TaskExecutor(poolSize);
    }

    public TaskScheduler(int poolSize,boolean isDaemon){
        this.taskRegistry = new TaskRegistry();
        this.taskExecutor = new TaskExecutor(poolSize,isDaemon);
    }

    public long register(Task task) {
        return taskRegistry.register(task);
    }

    public void execute(long taskId) {
        SafeTask task = taskRegistry.getTask(taskId);

        if (task == null) {
            throw new IllegalArgumentException("Task not found: " + taskId);
        }

        taskExecutor.execute(task);
    }

    public void shutdown() {
        taskExecutor.shutdown();
    }
}
