package classes;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

public class TaskRegistry {
    private final AtomicLong idGenerator = new AtomicLong(0);
    private final ConcurrentHashMap<Long, SafeTask> tasks = new ConcurrentHashMap<>();


    public long register(Task task) {
        long id = idGenerator.incrementAndGet();
        tasks.put(id, new SafeTask(task, "Task-" + id));
        return id;
    }

    public SafeTask getTask(long id) {
        return tasks.get(id);
    }

    public SafeTask removeTask(long id) {
        return tasks.remove(id);
    }

    public int getTaskCount() {
        return tasks.size();
    }


}
