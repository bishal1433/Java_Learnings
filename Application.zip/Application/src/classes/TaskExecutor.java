package classes;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TaskExecutor {
    private final ExecutorService executorService;

    public TaskExecutor(int poolSize) {
        this.executorService = Executors.newFixedThreadPool(poolSize);
    }
    public TaskExecutor(int poolSize,boolean isDaemon) {
        this.executorService = Executors.newFixedThreadPool(poolSize, r -> {
            Thread t = new Thread(r);
            t.setDaemon(isDaemon);
            return t;
        });
    }


    public void execute(SafeTask task) {
        executorService.submit(task::run);
    }

    public void shutdown() {
        executorService.shutdown();
    }



}
